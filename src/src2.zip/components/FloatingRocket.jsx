import { motion, useAnimation } from "framer-motion";
import { useEffect } from "react";
import rocket from "../assets/cohete-nuevo.png";
import useIsMobile from "../hooks/useIsMobile";

export default function FloatingRocket() {
  const isMobile = useIsMobile();
  const controls = useAnimation();

  useEffect(() => {
    async function animateRocket() {
      const target = isMobile
  ? { y: 80, x: 130, opacity: 1 }
  : { y: 50, x: Math.min(window.innerWidth * 0.75, 690), opacity: 1 };

      // Paso 1: animación de entrada
      await controls.start({
        ...target,
        transition: {
          duration: 2.5,
          ease: "easeOut",
          type: "spring",
          bounce: 0.2,
        },
      });

      // Paso 2: animación en loop (rebote)
      controls.start({
        y: [target.y, target.y - 10, target.y],
        x: [target.x, target.x + 10, target.x],
        transition: {
          duration: 3,
          repeat: Infinity,
          repeatType: "mirror",
          ease: "easeInOut",
        },
      });
    }

    animateRocket();
  }, [controls, isMobile]);

  return (
    <motion.div
      animate={controls}
      initial={{ y: -10, x: -100, opacity: 0 }}
      className="absolute top-0 left-0 z-0 pointer-events-none w-fit h-fit max-w-full overflow-hidden"
    >

      <img
        src={rocket}
        alt="Cohete Jet Vets flotando"
        className="w-28 md:w-60 opacity-100"
      />
    </motion.div>
  );
}