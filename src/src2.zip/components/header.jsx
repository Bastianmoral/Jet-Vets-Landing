// src/components/Header.jsx
import logo from '../assets/logo.png';

export default function Header() {
  return (
    <header className="bg-beige h-[70px] px-3 py-8 md:px-12 md:py-10 flex justify-between items-center">
      <img src={logo} alt="Jet Vets Logo" className="md:mt-5 h-[90px] md:h-[130px]" />
      <nav className="hidden md:flex md:gap-10 items-center">
        <a href="#nosotros" className="text-primary font-medium">Sobre Nosotros</a>
        <a href="#servicios" className="text-primary font-medium">Servicios</a>
        
  <a href="https://wa.me/34666666666" target="_blank" rel="noopener noreferrer">
    <img src="src\assets\icons8-whatsapp.svg" alt="WhatsApp" className="w-10 h-10" />
  </a>
  <a href="https://instagram.com/jetvets" target="_blank" rel="noopener noreferrer">
    <img src="src\assets\icons8-instagram.svg" alt="Instagram" className="w-8 h-10" />
  </a>

        <a href='/reserva' className="bg-[#5c7c4d] text-white px-4 py-2 rounded-lg mt-2 text-center">
            Reservar tu hora
          </a>
      </nav>
      <div className="md:hidden">
    <button className="text-primary pr-3 text-3xl font-bold">☰</button>
  </div>
    </header>

/*     <header className="bg-beige px-6 py-4 flex justify-between items-center">
  <img src={logo} alt="Jet Vets Logo" className="h-12 md:h-[90px]" />

  <nav className="hidden md:flex gap-10 items-center">
    <a href="#nosotros" className="text-primary font-medium">Sobre Nosotros</a>
    <a href="#servicios" className="text-primary font-medium">Servicios</a>
    <a href="#contacto" className="text-primary font-medium">Contacto</a>
    <button className="bg-primary text-white px-4 py-2 rounded">Reserva tu hora</button>
  </nav>

  <div className="md:hidden">
    <button className="text-primary text-2xl font-bold">☰</button>
  </div>
</header> */
  );
}
