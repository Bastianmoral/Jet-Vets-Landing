// src/components/FormularioReserva.jsx
import { useSearchParams } from 'react-router-dom';

export default function FormularioReserva() {
  const [searchParams] = useSearchParams();
  const asunto = searchParams.get('asunto') || '';

  return (
    <section className="min-h-screen bg-[#F6E9DF] flex flex-col items-center justify-center px-4">
      <h1 className="text-4xl volkhov-bold mb-8">RESERVA TU HORA</h1>
      <form className="bg-white p-8 rounded-xl shadow-md w-full max-w-md space-y-4">
        <div>
          <label className="block text-sm font-semibold mb-1">Nombre</label>
          <input type="text" name="nombre" className="w-full border rounded px-3 py-2" />
        </div>
        <div>
          <label className="block text-sm font-semibold mb-1">Correo</label>
          <input type="email" name="correo" className="w-full border rounded px-3 py-2" />
        </div>
        <div>
          <label className="block text-sm font-semibold mb-1">Asunto</label>
          <input type="text" name="asunto" value={asunto} readOnly className="w-full border rounded px-3 py-2 bg-gray-100" />
        </div>
        <div>
          <label className="block text-sm font-semibold mb-1">Mensaje</label>
          <textarea name="mensaje" className="w-full border rounded px-3 py-2 h-24"></textarea>
        </div>
        <button type="submit" className="bg-primary text-white px-6 py-2 rounded hover:bg-[#5c7c4d]">
          Reservar Hora
        </button>
      </form>
    </section>
  );
}

// Asegúrate que App.jsx tenga esta ruta:
// <Route path="/reserva" element={<FormularioReserva />} />

// Y que el botón de las cartas apunte a /reserva?asunto=...
