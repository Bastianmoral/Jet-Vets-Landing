import Header from '../components/header';
import Hero from '../components/hero';
import Footer from '../components/footer';
import SobreNosotros from '../components/SobreNosotros';
import Servicios from '../components/Servicios';

export default function Home() {
  return (
    <>
      <Header />
      <Hero />
      <Servicios />
      <SobreNosotros />
      <Footer />
    </>
  );
}

