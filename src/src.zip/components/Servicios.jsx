import ServicioCard from './ServicioCard';
import { FaStethoscope } from 'react-icons/fa';

export default function Servicios() {
  return (
    <section id="servicios" className="min-h-[100vh] px-6 py-[55px] bg-[#B89685] text-white text-center">
      <div className="mx-auto">
        <h2 className="text-3xl lg:text-5xl volkhov-bold pt-[25px] mb-12">Nuestros Servicios</h2>
        <div className="hidden lg:grid grid-cols-4 gap-8">
          <ServicioCard titulo="Consultas a Domicilio" descripcion="Atención veterinaria en la comodidad de tu hogar." icono={<FaStethoscope />} />
          <ServicioCard titulo="Vacunaciones y Desparasitaciones" descripcion="Mantén a tus mascotas protegidas con nuestras vacunas y desparasitaciones." icono={<FaStethoscope />} />
          <ServicioCard titulo="Identificación de Animales" descripcion="Microchips y placas de identificación para mayor seguridad." icono={<FaStethoscope />} />
          <ServicioCard titulo="Certificados de Salud y Viaje" descripcion="Documentación oficial para viajar tranquilo con tu mascota." icono={<FaStethoscope />} />
          <div className="col-span-4 flex justify-center gap-8">
            <ServicioCard titulo="Revisiones y Análisis Clínicos" descripcion="Chequeos completos y análisis de laboratorio a domicilio." icono={<FaStethoscope />} />
            <ServicioCard titulo="Atención Geriátrica" descripcion="Cuidados especiales para mascotas de edad avanzada." icono={<FaStethoscope />} />
            <ServicioCard titulo="Servicio de Urgencias" descripcion="Atención inmediata en casos de emergencia las 24h." icono={<FaStethoscope />} />
          </div>
        </div>
        <div className="flex gap-6 overflow-x-auto scrollbar-hide lg:hidden">
          <ServicioCard titulo="Consultas a Domicilio" descripcion="Atención veterinaria en la comodidad de tu hogar." icono={<FaStethoscope />} />
          <ServicioCard titulo="Vacunaciones y Desparasitaciones" descripcion="Mantén a tus mascotas protegidas con nuestras vacunas y desparasitaciones." icono={<FaStethoscope />} />
          <ServicioCard titulo="Identificación de Animales" descripcion="Microchips y placas de identificación para mayor seguridad." icono={<FaStethoscope />} />
          <ServicioCard titulo="Certificados de Salud y Viaje" descripcion="Documentación oficial para viajar tranquilo con tu mascota." icono={<FaStethoscope />} />
          <ServicioCard titulo="Revisiones y Análisis Clínicos" descripcion="Chequeos completos y análisis de laboratorio a domicilio." icono={<FaStethoscope />} />
          <ServicioCard titulo="Atención Geriátrica" descripcion="Cuidados especiales para mascotas de edad avanzada." icono={<FaStethoscope />} />
          <ServicioCard titulo="Servicio de Urgencias" descripcion="Atención inmediata en casos de emergencia las 24h." icono={<FaStethoscope />} />
        </div>
      </div>
    </section>
  );
}