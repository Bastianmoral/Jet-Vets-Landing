import { useState } from 'react';
import useIsMobile from '../hooks/useIsMobile';

export default function ServicioCard({ titulo, descripcion, icono }) {
  const [flipped, setFlipped] = useState(false);
  const isMobile = useIsMobile();

  const handleHover = (state) => {
    if (!isMobile) setFlipped(state);
  };

  return (
    <div
      className="relative w-[250px] h-[390px] md:w-[280px] md:h-[213px] cursor-pointer perspective shrink-0"
      onClick={() => isMobile && setFlipped(!flipped)}
      onMouseEnter={() => handleHover(true)}
      onMouseLeave={() => handleHover(false)}
    >
      <div
        className={`transition-transform duration-500 ease-in-out transform-style-preserve-3d w-full h-full ${flipped ? 'rotate-y-180' : ''}`}
      >
        {/* Front */}
        <div className="absolute w-full h-full backface-hidden bg-primary rounded-xl flex flex-col items-center justify-center text-white shadow-xl">
          <div className="text-xl volkhov-bold mb-2 text-center">{titulo}</div>
          <div className="text-4xl">{icono}</div>
        </div>

        {/* Back */}
        <div className="absolute w-full h-full backface-hidden rotate-y-180 bg-secondary1 rounded-xl flex flex-col items-center justify-center text-neutralDark shadow-xl p-4">
          <p className="text-sm mb-4 text-center">{descripcion}</p>
          <a href={`/reserva?asunto=${encodeURIComponent(titulo)}`} className="bg-accent text-white px-4 py-2 rounded-lg mt-2 hover:bg-[#5c7c4d] text-center">
            Reservar Hora
          </a>
        </div>
      </div>
    </div>
  );
}
